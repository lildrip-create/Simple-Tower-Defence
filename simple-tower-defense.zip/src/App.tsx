import { useEffect, useRef, useState } from 'react';
import { Shield, Activity, AlertTriangle, Crosshair, RotateCcw, Radar, Settings, Zap, Wrench, Plus, ArrowUp } from 'lucide-react';

// --- Game Constants & Types ---

interface GameState {
  funds: number;
  integrity: number;
  threatLevel: number;
  isGameOver: boolean;
  launchDetected: boolean;
  isJammed: boolean;
}

interface Building {
  x: number;
  width: number;
  height: number;
  maxHeight: number;
  hp: number;
  maxHp: number;
  fires: { x: number, y: number }[];
  windows: { x: number, y: number }[];
}

type ThreatType = 'missile' | 'drone' | 'heavy' | 'cluster' | 'submunition';

// --- Game Classes ---

class Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  gravity: number;
  friction: number;

  constructor(x: number, y: number, color: string, speedMult: number = 1, gravity: number = 0.1, friction: number = 0.98) {
    this.x = x;
    this.y = y;
    const angle = Math.random() * Math.PI * 2;
    const speed = (Math.random() * 3 + 1) * speedMult;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed;
    this.maxLife = Math.random() * 30 + 20;
    this.life = this.maxLife;
    this.color = color;
    this.size = Math.random() * 3 + 1;
    this.gravity = gravity;
    this.friction = friction;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += this.gravity;
    this.vx *= this.friction;
    this.life--;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
    ctx.fillStyle = this.color;
    ctx.fillRect(this.x - this.size, this.y - this.size, this.size * 2, this.size * 2);
    ctx.globalAlpha = 1.0;
  }
}

class Civilian {
  x: number;
  y: number;
  vx: number;
  vy: number;
  dead: boolean;
  isFlung: boolean;

  constructor() {
    this.x = Math.random() * 800;
    this.y = 450;
    this.vx = (Math.random() - 0.5) * 0.8;
    this.vy = 0;
    this.dead = false;
    this.isFlung = false;
  }

  update(game: any, panic: boolean) {
    if (this.isFlung) {
      this.x += this.vx;
      this.y += this.vy;
      this.vy += 0.2; // gravity
      
      // Add particle effect for flung civilian (dust/smoke trail)
      if (Math.random() < 0.4) {
        const p = new Particle(this.x, this.y - 3, "#cbd5e1", 0.4, -0.02, 0.9);
        p.maxLife = 15 + Math.random() * 15;
        p.life = p.maxLife;
        p.size = 2 + Math.random() * 2;
        game.particles.push(p);
      }

      if (this.y >= 450) {
        this.y = 450;
        this.isFlung = false;
        this.vx = (Math.random() - 0.5) * 0.8;
      }
      return;
    }

    let speed = panic ? this.vx * 3 : this.vx;
    this.x += speed;
    
    // Wrap around screen
    if (this.x < -10) this.x = 810;
    if (this.x > 810) this.x = -10;
    
    // Randomly change direction occasionally if not panicking
    if (!panic && Math.random() < 0.01) {
      this.vx *= -1;
    }
  }

  draw(ctx: CanvasRenderingContext2D, panic: boolean) {
    ctx.fillStyle = panic ? "#f87171" : "#94a3b8";
    // Draw a tiny stick figure/rect
    ctx.fillRect(this.x - 1, this.y - 6, 2, 6);
    ctx.fillRect(this.x - 2, this.y - 4, 4, 1); // arms
  }
}

class Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  life: number;
  maxLife: number;
  color: string;

  constructor(x: number, y: number, maxRadius: number, color: string) {
    this.x = x;
    this.y = y;
    this.radius = 0;
    this.maxRadius = maxRadius;
    this.maxLife = 20;
    this.life = this.maxLife;
    this.color = color;
  }

  update() {
    this.radius += (this.maxRadius - this.radius) * 0.2;
    this.life--;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
    ctx.strokeStyle = this.color;
    ctx.lineWidth = 3 * (this.life / this.maxLife);
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.stroke();
    
    // Inner flash
    ctx.fillStyle = this.color;
    ctx.globalAlpha = Math.max(0, (this.life / this.maxLife) * 0.3);
    ctx.fill();
    ctx.globalAlpha = 1.0;
  }
}

class Threat {
  x: number;
  y: number;
  startX: number;
  startY: number;
  targetX: number;
  targetY: number;
  vx: number;
  vy: number;
  speed: number;
  dead: boolean;
  trail: {x: number, y: number}[];
  type: ThreatType;
  hp: number;
  maxHp: number;
  time: number;
  hasSplit: boolean;
  evadedCount: number;

  constructor(targetX: number, speedMultiplier: number, forcedType?: ThreatType, startX?: number, startY?: number) {
    this.startX = startX ?? Math.random() * 800;
    this.startY = startY ?? 10;
    this.x = this.startX;
    this.y = this.startY;
    this.targetX = targetX;
    this.targetY = 450;
    this.dead = false;
    this.trail = [];
    this.time = 0;
    this.hasSplit = false;
    this.evadedCount = 0;

    if (forcedType) {
      this.type = forcedType;
    } else {
      const rand = Math.random();
      if (rand < 0.15) {
        this.type = 'heavy';
      } else if (rand < 0.30) {
        this.type = 'cluster';
      } else if (rand < 0.55) {
        this.type = 'drone';
      } else {
        this.type = 'missile';
      }
    }

    if (this.type === 'heavy') {
      this.speed = 0.5 * speedMultiplier;
      this.maxHp = 6;
    } else if (this.type === 'cluster') {
      this.speed = 0.8 * speedMultiplier;
      this.maxHp = 2;
    } else if (this.type === 'drone') {
      this.speed = 1.0 * speedMultiplier;
      this.maxHp = 1;
    } else if (this.type === 'submunition') {
      this.speed = 1.4 * speedMultiplier;
      this.maxHp = 1;
    } else {
      this.speed = 1.2 * speedMultiplier;
      this.maxHp = 1;
    }
    this.hp = this.maxHp;

    const dx = this.targetX - this.startX;
    const dy = this.targetY - this.startY;
    const dist = Math.hypot(dx, dy);
    this.vx = (dx / dist) * this.speed;
    this.vy = (dy / dist) * this.speed;
  }

  update(game: Game) {
    this.time++;
    this.trail.push({ x: this.x, y: this.y });
    if (this.trail.length > (this.type === 'drone' ? 30 : 15)) this.trail.shift();

    if (this.type === 'drone') {
      this.x += this.vx + Math.sin(this.time * 0.1) * 2;
      this.y += this.vy;
    } else {
      this.x += this.vx;
      this.y += this.vy;
    }

    if (this.type === 'cluster' && this.y > 150 && !this.hasSplit) {
      this.hasSplit = true;
      this.dead = true;
      game.shockwaves.push(new Shockwave(this.x, this.y, 80, "#FBBF24"));
      
      for(let i=0; i<16; i++) {
        const spreadX = this.targetX + (Math.random() - 0.5) * 400;
        const sub = new Threat(spreadX, this.speed * 1.2, 'submunition', this.x, this.y);
        sub.vx += (Math.random() - 0.5) * 4;
        sub.vy += (Math.random() - 0.5) * 2;
        game.threats.push(sub);
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (this.trail.length > 1) {
      ctx.beginPath();
      ctx.moveTo(this.trail[0].x, this.trail[0].y);
      for (let i = 1; i < this.trail.length; i++) {
        ctx.lineTo(this.trail[i].x, this.trail[i].y);
      }
      
      let color = "";
      let glowColor = "";
      let thickness = 2;
      
      if (this.type === 'heavy') {
        color = "rgba(249, 115, 22, 0.8)";
        glowColor = "rgba(249, 115, 22, 1)";
        thickness = 4;
      } else if (this.type === 'cluster') {
        color = "rgba(250, 204, 21, 0.8)";
        glowColor = "rgba(250, 204, 21, 1)";
        thickness = 3;
      } else if (this.type === 'drone') {
        color = "rgba(168, 85, 247, 0.8)";
        glowColor = "rgba(168, 85, 247, 1)";
        thickness = 2;
      } else if (this.type === 'submunition') {
        color = "rgba(253, 224, 71, 0.6)";
        glowColor = "rgba(253, 224, 71, 1)";
        thickness = 1;
      } else {
        color = "rgba(239, 68, 68, 0.8)";
        glowColor = "rgba(239, 68, 68, 1)";
        thickness = 2;
      }
      
      ctx.strokeStyle = color;
      ctx.lineWidth = thickness;
      
      // Fake glow with a thicker transparent line underneath
      ctx.save();
      ctx.strokeStyle = glowColor.replace('1)', '0.3)');
      ctx.lineWidth = thickness * 3;
      ctx.stroke();
      ctx.restore();
      
      ctx.stroke();
    }

    ctx.save();
    ctx.translate(this.x, this.y);
    
    // Fake glow for the projectile body
    ctx.fillStyle = this.type === 'heavy' ? "rgba(249, 115, 22, 0.4)" : 
                    this.type === 'cluster' ? "rgba(250, 204, 21, 0.4)" :
                    this.type === 'drone' ? "rgba(168, 85, 247, 0.4)" :
                    this.type === 'submunition' ? "rgba(253, 224, 71, 0.4)" :
                    "rgba(239, 68, 68, 0.4)";
    ctx.beginPath();
    ctx.arc(0, 0, this.type === 'heavy' ? 12 : 8, 0, Math.PI * 2);
    ctx.fill();

    if (this.type === 'missile') {
      const angle = Math.atan2(this.vy, this.vx);
      ctx.rotate(angle);
      ctx.fillStyle = "#EF4444";
      ctx.beginPath();
      ctx.moveTo(8, 0);
      ctx.lineTo(-6, 4);
      ctx.lineTo(-6, -4);
      ctx.closePath();
      ctx.fill();
    } else if (this.type === 'drone') {
      ctx.fillStyle = "#A855F7";
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#D8B4FE";
      ctx.beginPath(); ctx.arc(-5, -5, 2, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(5, -5, 2, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(-5, 5, 2, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(5, 5, 2, 0, Math.PI*2); ctx.fill();
    } else if (this.type === 'cluster') {
      const angle = Math.atan2(this.vy, this.vx);
      ctx.rotate(angle);
      ctx.fillStyle = "#FACC15";
      ctx.beginPath();
      ctx.moveTo(12, 0);
      ctx.lineTo(0, 8);
      ctx.lineTo(-12, 0);
      ctx.lineTo(0, -8);
      ctx.closePath();
      ctx.fill();
    } else if (this.type === 'submunition') {
      const angle = Math.atan2(this.vy, this.vx);
      ctx.rotate(angle);
      ctx.fillStyle = "#FDE047";
      ctx.beginPath();
      ctx.moveTo(6, 0);
      ctx.lineTo(-4, 3);
      ctx.lineTo(-4, -3);
      ctx.closePath();
      ctx.fill();
    } else if (this.type === 'heavy') {
      const angle = Math.atan2(this.vy, this.vx);
      ctx.rotate(angle);
      ctx.fillStyle = "#F97316";
      ctx.fillRect(-12, -8, 24, 16);
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(4, -3, 6, 6);
      
      ctx.rotate(-angle);
      ctx.fillStyle = "red";
      ctx.fillRect(-15, -20, 30, 4);
      ctx.fillStyle = "lime";
      ctx.fillRect(-15, -20, 30 * (this.hp / this.maxHp), 4);
    }
    
    ctx.restore();
  }
}

class Interceptor {
  x: number;
  y: number;
  vx: number;
  vy: number;
  target: Threat | null;
  speed: number;
  dead: boolean;
  trail: {x: number, y: number}[];
  fuel: number;
  willMiss: boolean;
  missOffset: { x: number, y: number };
  rogue: boolean;

  constructor(x: number, y: number, target: Threat) {
    this.x = x;
    this.y = y;
    this.target = target;
    this.speed = 9;
    this.dead = false;
    this.trail = [];
    this.fuel = 150;
    this.rogue = false;
    
    this.vx = (Math.random() - 0.5) * 4;
    this.vy = -this.speed;
    
    // 15% chance to miss the target
    this.willMiss = Math.random() < 0.15;
    this.missOffset = { 
      x: (Math.random() > 0.5 ? 1 : -1) * (Math.random() * 50 + 30), 
      y: (Math.random() > 0.5 ? 1 : -1) * (Math.random() * 50 + 30) 
    };
  }

  update(game: Game) {
    if (this.rogue) {
      this.vy += 0.15; // gravity takes over
      this.x += this.vx;
      this.y += this.vy;
      
      this.trail.push({ x: this.x, y: this.y });
      if (this.trail.length > 8) this.trail.shift();
      
      // Add smoke to indicate it's failing
      if (Math.random() < 0.4) {
        game.particles.push(new Particle(this.x, this.y, "#52525b", 0.5));
      }

      if (this.y >= 450) {
        this.dead = true;
        // Ground explosion!
        game.shockwaves.push(new Shockwave(this.x, 450, 60, "#EF4444"));
        for(let i=0; i<15; i++) {
          game.particles.push(new Particle(this.x, 450, "#EF4444", 2, 0.1, 0.98));
          game.particles.push(new Particle(this.x, 450, "#F97316", 2, 0.1, 0.98));
        }
        
        // Damage buildings
        for (const b of game.buildings) {
          if (Math.abs(b.x + b.width/2 - this.x) < b.width/2 + 40) {
            b.hp -= 20; // Interceptors do some damage
            if (b.hp < 0) b.hp = 0;
            if (Math.random() < 0.5) {
              b.fires.push({x: this.x, y: 450 - b.height});
            }
          }
        }
        // Kill/fling civilians
        for (const c of game.civilians) {
          if (!c.dead) {
            const dist = Math.abs(c.x - this.x);
            if (dist < 40) {
              c.dead = true;
              game.funds = Math.max(0, game.funds - 50); // Penalty for killing civilian
            } else if (dist < 80) {
              c.isFlung = true;
              c.vx = (c.x - this.x) * 0.1;
              c.vy = -3 - Math.random() * 3;
            }
          }
        }
      }
      return;
    }

    this.fuel--;
    if (this.fuel <= 0) {
      this.rogue = true;
      return;
    }

    this.trail.push({ x: this.x, y: this.y });
    if (this.trail.length > 8) this.trail.shift();

    if (!this.target || this.target.dead) {
      const newTarget = game.threats.find(m => !m.dead && m.y > 0);
      if (newTarget) {
        this.target = newTarget;
      } else {
        this.rogue = true;
        return;
      }
    }

    let targetX = this.target.x;
    let targetY = this.target.y;
    
    if (this.willMiss) {
      targetX += this.missOffset.x;
      targetY += this.missOffset.y;
    }

    const dx = targetX - this.x;
    const dy = targetY - this.y;
    const dist = Math.hypot(dx, dy);

    if (dist < 15) {
      if (this.willMiss) {
        // Become rogue instead of exploding harmlessly
        this.rogue = true;
        this.vx = (Math.random() - 0.5) * 6; // Tumble
        this.vy = -2 - Math.random() * 3; // Slight upward bump before falling
        this.target.evadedCount++;
        return;
      }
      
      this.target.hp--;
      if (this.target.hp <= 0) {
        this.target.dead = true;
        game.funds += this.target.type === 'heavy' ? 100 : 
                      this.target.type === 'cluster' ? 50 : 
                      this.target.type === 'drone' ? 40 : 
                      this.target.type === 'submunition' ? 10 : 25;
        
        // Increase intensity when successfully intercepting a missile
        game.threatLevel += 0.15;
      }
      
      this.dead = true;
      game.shockwaves.push(new Shockwave(this.x, this.y, 40, "#38BDF8"));
      
      for(let i=0; i<8; i++) {
        game.particles.push(new Particle(this.x, this.y, "#38BDF8", 1.5));
        game.particles.push(new Particle(this.x, this.y, "#FFFFFF", 2));
      }
      return;
    }

    const desiredVx = (dx / dist) * this.speed;
    const desiredVy = (dy / dist) * this.speed;
    
    const turnSpeed = 0.2;
    this.vx += (desiredVx - this.vx) * turnSpeed;
    this.vy += (desiredVy - this.vy) * turnSpeed;

    const currentSpeed = Math.hypot(this.vx, this.vy);
    this.vx = (this.vx / currentSpeed) * this.speed;
    this.vy = (this.vy / currentSpeed) * this.speed;

    this.x += this.vx;
    this.y += this.vy;
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (this.trail.length > 1) {
      ctx.beginPath();
      ctx.moveTo(this.trail[0].x, this.trail[0].y);
      for (let i = 1; i < this.trail.length; i++) {
        ctx.lineTo(this.trail[i].x, this.trail[i].y);
      }
      
      // Fake glow using a thicker, transparent line
      ctx.save();
      ctx.strokeStyle = this.rogue ? "rgba(239, 68, 68, 0.3)" : "rgba(56, 189, 248, 0.3)";
      ctx.lineWidth = 6;
      ctx.stroke();
      ctx.restore();
      
      ctx.strokeStyle = this.rogue ? "rgba(239, 68, 68, 0.8)" : "rgba(56, 189, 248, 0.8)";
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    ctx.fillStyle = this.rogue ? "#F87171" : "#FFFFFF";
    ctx.beginPath();
    ctx.arc(this.x, this.y, 2, 0, Math.PI * 2);
    ctx.fill();
  }
}

interface PendingLaunch {
  target: Threat;
  delay: number;
  maxDelay: number;
}

class Battery {
  x: number;
  y: number;
  range: number;
  cooldown: number;
  maxCooldown: number;
  lockedTarget: Threat | null;
  pendingLaunches: PendingLaunch[];

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.range = 450;
    this.cooldown = 0;
    this.maxCooldown = 20;
    this.lockedTarget = null;
    this.pendingLaunches = [];
  }

  update(game: Game) {
    if (this.cooldown > 0) this.cooldown--;
    
    if (this.lockedTarget && this.lockedTarget.dead) {
      this.lockedTarget = null;
    }

    // Process pending delayed launches
    for (let i = this.pendingLaunches.length - 1; i >= 0; i--) {
      const launch = this.pendingLaunches[i];
      
      // Cancel launch if target is destroyed or invalid (hit ground)
      if (launch.target.dead || launch.target.y >= 450) {
        this.pendingLaunches.splice(i, 1);
        continue;
      }

      launch.delay--;
      if (launch.delay <= 0) {
        game.interceptors.push(new Interceptor(this.x, this.y, launch.target));
        game.shockwaves.push(new Shockwave(this.x, this.y, 25, "#eab308")); // Launch flash
        // Launch smoke
        for(let k=0; k<5; k++) {
          const p = new Particle(this.x, this.y, "#94a3b8", 1, -0.05, 0.9);
          p.maxLife = 40; p.life = 40; p.size = 4;
          game.particles.push(p);
        }
        this.pendingLaunches.splice(i, 1);
      }
    }

    if (game.jamTimer > 0) {
      this.lockedTarget = null;
      return; // Cannot lock new targets while jammed
    }

    if (this.cooldown <= 0) {
      let bestTarget: Threat | null = null;
      let maxThreatScore = -1;

      for (const m of game.threats) {
        if (m.dead || m.y < 0) continue;
        const dist = Math.hypot(m.x - this.x, m.y - this.y);
        
        if (dist < this.range) {
          let interceptorsChasing = 0;
          for (let i = 0; i < game.interceptors.length; i++) {
            if (game.interceptors[i].target === m && !game.interceptors[i].rogue) {
              interceptorsChasing++;
            }
          }
          for (let b = 0; b < game.batteries.length; b++) {
            for (let p = 0; p < game.batteries[b].pendingLaunches.length; p++) {
              if (game.batteries[b].pendingLaunches[p].target === m) {
                interceptorsChasing++;
              }
            }
          }
          
          const maxInterceptors = m.type === 'heavy' ? 6 : m.type === 'cluster' ? 3 : 1;
          
          if (interceptorsChasing < maxInterceptors) {
            let score = m.y; // Prioritize threats closer to the ground (higher Y)
            
            // Prioritize by type
            if (m.type === 'cluster') score += 300;
            else if (m.type === 'heavy') score += 200;
            else if (m.type === 'drone') score += 100;
            
            // Prioritize threats that have evaded interception
            score += m.evadedCount * 150;
            
            // De-prioritize if already being engaged by some interceptors (to spread fire)
            score -= interceptorsChasing * 50;

            if (score > maxThreatScore) {
              maxThreatScore = score;
              bestTarget = m;
            }
          }
        }
      }

      if (bestTarget) {
        this.lockedTarget = bestTarget;
        // Add a variable delay (10-20 frames) before actually firing to add drama
        const delay = Math.floor(Math.random() * 11) + 10;
        this.pendingLaunches.push({ target: bestTarget, delay: delay, maxDelay: delay });
        this.cooldown = this.maxCooldown;
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (this.lockedTarget && !this.lockedTarget.dead) {
      ctx.strokeStyle = "rgba(56, 189, 248, 0.15)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(this.x, this.y);
      ctx.lineTo(this.lockedTarget.x, this.lockedTarget.y);
      ctx.stroke();

      ctx.strokeStyle = "#38BDF8";
      ctx.lineWidth = 1;
      ctx.strokeRect(this.lockedTarget.x - 12, this.lockedTarget.y - 12, 24, 24);
      
      ctx.beginPath();
      ctx.moveTo(this.lockedTarget.x, this.lockedTarget.y - 16); ctx.lineTo(this.lockedTarget.x, this.lockedTarget.y - 8);
      ctx.moveTo(this.lockedTarget.x, this.lockedTarget.y + 16); ctx.lineTo(this.lockedTarget.x, this.lockedTarget.y + 8);
      ctx.moveTo(this.lockedTarget.x - 16, this.lockedTarget.y); ctx.lineTo(this.lockedTarget.x - 8, this.lockedTarget.y);
      ctx.moveTo(this.lockedTarget.x + 16, this.lockedTarget.y); ctx.lineTo(this.lockedTarget.x + 8, this.lockedTarget.y);
      ctx.stroke();
    }

    // Draw charging laser for pending launches
    for (const p of this.pendingLaunches) {
      if (!p.target.dead) {
        ctx.strokeStyle = `rgba(234, 179, 8, ${1 - p.delay / p.maxDelay})`; // Yellow charging laser
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        ctx.lineTo(p.target.x, p.target.y);
        ctx.stroke();
      }
    }

    ctx.fillStyle = "#334155";
    ctx.fillRect(this.x - 15, this.y - 10, 30, 10);
    
    ctx.fillStyle = "#94A3B8";
    ctx.beginPath();
    ctx.arc(this.x, this.y - 10, 10, Math.PI, 0);
    ctx.fill();

    ctx.strokeStyle = "rgba(56, 189, 248, 0.05)";
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.range, 0, Math.PI * 2);
    ctx.stroke();
  }
}

class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  funds: number;
  integrity: number;
  threatLevel: number;
  batteries: Battery[];
  threats: Threat[];
  interceptors: Interceptor[];
  shockwaves: Shockwave[];
  particles: Particle[];
  buildings: Building[];
  civilians: Civilian[];
  stars: {x: number, y: number}[];
  bgGradient: CanvasGradient;
  radarGradient: CanvasGradient;
  lanterns: {x: number}[];
  benches: {x: number}[];
  
  spawnTimer: number;
  launchWarningTimer: number;
  jamTimer: number;
  radarAngle: number;
  animationFrameId: number;
  isGameOver: boolean;
  onStateChange: (state: GameState) => void;

  constructor(canvas: HTMLCanvasElement, onStateChange: (state: GameState) => void) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.onStateChange = onStateChange;
    
    this.funds = 600;
    this.integrity = 100;
    this.threatLevel = 1;
    this.batteries = [];
    this.threats = [];
    this.interceptors = [];
    this.shockwaves = [];
    this.particles = [];
    this.civilians = [];
    
    this.spawnTimer = 240;
    this.launchWarningTimer = 0;
    this.jamTimer = 0;
    this.radarAngle = 0;
    this.animationFrameId = 0;
    this.isGameOver = false;

    this.buildings = [];
    let currentX = 0;
    while (currentX < 800) {
      const width = Math.random() * 40 + 30;
      const height = Math.random() * 80 + 20;
      
      const windows = [];
      for(let wy = 450 - height + 10; wy < 440; wy += 15) {
        for(let wx = currentX + 5; wx < currentX + width - 10; wx += 10) {
          if (Math.random() > 0.3) windows.push({x: wx, y: wy});
        }
      }

      this.buildings.push({ 
        x: currentX, 
        width, 
        height, 
        maxHeight: height, 
        hp: 100, 
        maxHp: 100,
        fires: [],
        windows
      });
      currentX += width + Math.random() * 10;
    }

    this.stars = [];
    for(let i=0; i<50; i++) {
      const sx = Math.sin(i * 123) * 800;
      const sy = Math.cos(i * 321) * 300;
      this.stars.push({x: Math.abs(sx), y: Math.abs(sy)});
    }

    this.bgGradient = this.ctx.createLinearGradient(0, 0, 0, 450);
    this.bgGradient.addColorStop(0, "#020617");
    this.bgGradient.addColorStop(1, "#1e1b4b");

    this.radarGradient = this.ctx.createRadialGradient(0, 0, 0, 0, 0, 800);
    this.radarGradient.addColorStop(0, "rgba(34, 197, 94, 0.15)");
    this.radarGradient.addColorStop(1, "rgba(34, 197, 94, 0)");

    this.lanterns = [];
    for(let i=20; i<800; i+=70) {
      if (Math.random() > 0.2) this.lanterns.push({x: i});
    }
    this.benches = [];
    for(let i=0; i<10; i++) {
      this.benches.push({x: Math.random() * 800});
    }

    for(let i=0; i<30; i++) {
      this.civilians.push(new Civilian());
    }

    this.batteries.push(new Battery(400, 450));

    this.handleClick = this.handleClick.bind(this);
    this.canvas.addEventListener('click', this.handleClick);
    
    this.notifyState();
  }

  notifyState() {
    this.onStateChange({
      funds: this.funds,
      integrity: this.integrity,
      threatLevel: this.threatLevel,
      isGameOver: this.isGameOver,
      launchDetected: this.launchWarningTimer > 0,
      isJammed: this.jamTimer > 0
    });
  }

  handleClick(e: MouseEvent) {
    if (this.isGameOver) return;

    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (y < 400) return;

    const cost = 300;
    if (this.funds >= cost) {
      const tooClose = this.batteries.some(b => Math.abs(b.x - x) < 60);
      if (!tooClose) {
        this.batteries.push(new Battery(x, 450));
        this.funds -= cost;
        this.notifyState();
      }
    }
  }

  drawBackground() {
    this.ctx.fillStyle = this.bgGradient;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    this.ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
    for(const star of this.stars) {
      this.ctx.fillRect(star.x, star.y, 1, 1);
    }

    this.radarAngle += 0.03;
    this.ctx.save();
    this.ctx.translate(400, 450);
    this.ctx.rotate(this.radarAngle);
    this.ctx.beginPath();
    this.ctx.moveTo(0, 0);
    this.ctx.arc(0, 0, 800, 0, -Math.PI / 4, true);
    this.ctx.fillStyle = this.radarGradient;
    this.ctx.fill();
    this.ctx.restore();

    this.ctx.fillStyle = "#0f172a";
    this.ctx.fillRect(0, 450, this.canvas.width, 50);

    for (const b of this.buildings) {
      // Draw building darker if damaged
      const damageRatio = b.hp / b.maxHp;
      this.ctx.fillStyle = `rgb(${30 * damageRatio}, ${41 * damageRatio}, ${59 * damageRatio})`;
      this.ctx.fillRect(b.x, 450 - b.height, b.width, b.height);
      
      this.ctx.fillStyle = `rgba(250, 204, 21, ${0.2 * damageRatio})`;
      for (const w of b.windows) {
        if (w.y >= 450 - b.height) {
          // During EMP, 80% of windows turn off stably based on their coordinates
          if (this.jamTimer > 0 && (w.x * 17 + w.y * 23) % 10 < 8) continue;
          this.ctx.fillRect(w.x, w.y, 4, 8);
        }
      }
    }

    // Draw environment (benches, lanterns)
    for (const b of this.benches) {
      this.ctx.fillStyle = "#334155";
      this.ctx.fillRect(b.x, 440, 15, 4); // seat
      this.ctx.fillRect(b.x + 2, 444, 2, 6); // leg 1
      this.ctx.fillRect(b.x + 11, 444, 2, 6); // leg 2
    }

    for (const l of this.lanterns) {
      this.ctx.fillStyle = "#475569";
      this.ctx.fillRect(l.x - 1.5, 410, 3, 40); // pole
      if (this.jamTimer <= 0) {
        this.ctx.fillStyle = "#fef08a"; // light
        this.ctx.beginPath();
        this.ctx.arc(l.x, 410, 4, 0, Math.PI*2);
        this.ctx.fill();
        // glow
        this.ctx.fillStyle = "rgba(254, 240, 138, 0.15)";
        this.ctx.beginPath();
        this.ctx.arc(l.x, 410, 15, 0, Math.PI*2);
        this.ctx.fill();
      } else {
        this.ctx.fillStyle = "#1e293b"; // off light
        this.ctx.beginPath();
        this.ctx.arc(l.x, 410, 4, 0, Math.PI*2);
        this.ctx.fill();
      }
    }
  }

  drawTrajectories() {
    this.ctx.setLineDash([5, 5]);
    for (const m of this.threats) {
      if (m.y < 0) continue;
      
      let color = "";
      let thickness = 1;
      
      if (m.type === 'heavy') { color = "rgba(249, 115, 22, 0.3)"; thickness = 2; }
      else if (m.type === 'cluster') { color = "rgba(250, 204, 21, 0.3)"; thickness = 1.5; }
      else if (m.type === 'submunition') { color = "rgba(253, 224, 71, 0.15)"; thickness = 0.5; }
      else if (m.type === 'drone') { color = "rgba(168, 85, 247, 0.3)"; thickness = 1.5; }
      else { color = "rgba(239, 68, 68, 0.3)"; thickness = 1; }

      this.ctx.strokeStyle = color;
      this.ctx.lineWidth = thickness;
      
      this.ctx.beginPath();
      this.ctx.moveTo(m.x, m.y);
      
      let projX = m.targetX;
      if (m.type === 'drone') {
        const timeToGround = (450 - m.y) / m.vy;
        projX = m.x + m.vx * timeToGround;
      }
      
      this.ctx.lineTo(projX, 450);
      this.ctx.stroke();
      
      this.ctx.beginPath();
      this.ctx.ellipse(projX, 450, 15 * thickness, 5 * thickness, 0, 0, Math.PI*2);
      this.ctx.stroke();
    }
    this.ctx.setLineDash([]);
  }

  update() {
    if (this.isGameOver) return;

    let stateChanged = false;
    this.threatLevel += 0.0005; // Reduced passive increase

    if (this.jamTimer > 0) {
      this.jamTimer--;
      if (this.jamTimer === 0) stateChanged = true;
    } else if (Math.random() < 0.0001 + (this.threatLevel * 0.00005)) {
      this.jamTimer = 240; // 4 seconds of jamming
      stateChanged = true;
    }

    this.spawnTimer--;
    if (this.spawnTimer <= 0) {
      const targetX = Math.random() * 800;
      const newThreat = new Threat(targetX, 1 + (this.threatLevel * 0.15));
      this.threats.push(newThreat);
      
      this.shockwaves.push(new Shockwave(newThreat.startX, newThreat.startY, 80, "#FBBF24"));
      
      // Much longer pauses between missiles, but scales down as threat increases
      this.spawnTimer = Math.max(60, 300 - this.threatLevel * 15);
      this.launchWarningTimer = 60;
      stateChanged = true;
    }

    if (this.launchWarningTimer > 0) {
      this.launchWarningTimer--;
      if (this.launchWarningTimer === 0) stateChanged = true;
    }

    this.civilians.forEach(c => c.update(this, this.launchWarningTimer > 0));
    this.batteries.forEach(b => b.update(this));
    this.interceptors.forEach(i => i.update(this));
    this.threats.forEach(m => m.update(this));
    this.shockwaves.forEach(s => s.update());
    this.particles.forEach(p => p.update());

    // Spawn smoke and fire from damaged buildings
    for (const b of this.buildings) {
      for (const f of b.fires) {
        if (Math.random() < 0.15) {
          // Smoke
          const p = new Particle(f.x + (Math.random()-0.5)*15, f.y, "#334155", 0.5, -0.02, 0.95);
          p.maxLife = 60 + Math.random() * 40;
          p.life = p.maxLife;
          p.size = 4 + Math.random() * 4;
          this.particles.push(p);
        }
        if (Math.random() < 0.25) {
          // Fire
          const p = new Particle(f.x + (Math.random()-0.5)*10, f.y, "#ea580c", 0.8, -0.05, 0.9);
          p.maxLife = 20 + Math.random() * 10;
          p.life = p.maxLife;
          this.particles.push(p);
        }
      }
    }

    for (let i = this.threats.length - 1; i >= 0; i--) {
      const m = this.threats[i];
      if (m.y >= 450 && !m.dead) {
        m.dead = true;
        
        const blastRadius = m.type === 'heavy' ? 100 : m.type === 'cluster' ? 60 : m.type === 'submunition' ? 20 : 40;
        this.shockwaves.push(new Shockwave(m.x, 450, blastRadius * 1.5, "#EF4444"));
        
        const damage = m.type === 'heavy' ? 25 : 
                       m.type === 'cluster' ? 15 : 
                       m.type === 'submunition' ? 2 : 
                       m.type === 'drone' ? 5 : 10;
        this.integrity -= damage;
        stateChanged = true;

        // Damage buildings
        for (const b of this.buildings) {
          if (m.x >= b.x - blastRadius && m.x <= b.x + b.width + blastRadius) {
            b.hp -= damage * 2;
            if (b.hp < 0) b.hp = 0;
            b.height = Math.max(5, (b.hp / b.maxHp) * b.maxHeight);
            
            // Add fire source
            if (Math.random() > 0.2 && b.fires.length < 3) {
              b.fires.push({ x: m.x, y: 450 - b.height });
            }
          }
        }

        // Kill civilians or fling them
        for (const c of this.civilians) {
          if (!c.dead && !c.isFlung) {
            const dist = Math.abs(c.x - m.x);
            if (dist < blastRadius) {
              if (dist < blastRadius * 0.5) {
                c.dead = true;
                for(let k=0; k<5; k++) {
                  this.particles.push(new Particle(c.x, c.y, "#dc2626", 1, 0.1, 0.9));
                }
              } else {
                c.isFlung = true;
                c.vy = -Math.random() * 5 - 2;
                c.vx = (c.x - m.x > 0 ? 1 : -1) * (Math.random() * 3 + 1);
              }
            }
          }
        }
        
        for(let j=0; j < (m.type === 'heavy' ? 20 : 10); j++) {
          this.particles.push(new Particle(m.x, 450, "#EF4444", 2, 0.1, 0.98));
          this.particles.push(new Particle(m.x, 450, "#F97316", 2, 0.1, 0.98));
        }

        if (this.integrity <= 0) {
          this.integrity = 0;
          this.isGameOver = true;
        }
      }
    }

    let tIdx = 0;
    for (let i = 0; i < this.threats.length; i++) {
      if (!this.threats[i].dead) this.threats[tIdx++] = this.threats[i];
    }
    this.threats.length = tIdx;

    let iIdx = 0;
    for (let i = 0; i < this.interceptors.length; i++) {
      if (!this.interceptors[i].dead) this.interceptors[iIdx++] = this.interceptors[i];
    }
    this.interceptors.length = iIdx;

    let sIdx = 0;
    for (let i = 0; i < this.shockwaves.length; i++) {
      if (this.shockwaves[i].life > 0) this.shockwaves[sIdx++] = this.shockwaves[i];
    }
    this.shockwaves.length = sIdx;

    let pIdx = 0;
    for (let i = 0; i < this.particles.length; i++) {
      if (this.particles[i].life > 0) this.particles[pIdx++] = this.particles[i];
    }
    this.particles.length = pIdx;
    
    // Cap particles to prevent extreme slowdowns during massive explosions
    if (this.particles.length > 1500) {
      this.particles.length = 1500;
    }

    let cIdx = 0;
    for (let i = 0; i < this.civilians.length; i++) {
      if (!this.civilians[i].dead) this.civilians[cIdx++] = this.civilians[i];
    }
    this.civilians.length = cIdx;

    if (stateChanged) this.notifyState();
  }

  draw() {
    this.drawBackground();
    this.drawTrajectories();
    
    this.ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
    this.ctx.lineWidth = 2;
    this.ctx.beginPath();
    this.ctx.moveTo(0, 450);
    this.ctx.lineTo(800, 450);
    this.ctx.stroke();

    this.civilians.forEach(c => c.draw(this.ctx, this.launchWarningTimer > 0));
    this.batteries.forEach(b => b.draw(this.ctx));
    this.threats.forEach(m => m.draw(this.ctx));
    this.interceptors.forEach(i => i.draw(this.ctx));
    this.shockwaves.forEach(s => s.draw(this.ctx));
    this.particles.forEach(p => p.draw(this.ctx));

    if (this.launchWarningTimer > 0 && !this.jamTimer) {
      this.ctx.fillStyle = `rgba(239, 68, 68, ${Math.abs(Math.sin(this.launchWarningTimer * 0.2))})`;
      this.ctx.font = "bold 32px monospace";
      this.ctx.textAlign = "center";
      this.ctx.fillText("⚠️ LAUNCH DETECTED ⚠️", 400, 100);
    }
    
    if (this.jamTimer > 0) {
      this.ctx.fillStyle = `rgba(168, 85, 247, ${Math.abs(Math.sin(this.jamTimer * 0.2))})`;
      this.ctx.font = "bold 32px monospace";
      this.ctx.textAlign = "center";
      this.ctx.fillText("⚡ JAMMER ACTIVE EMP ⚡", 400, 100);
      
      // Draw static/glitch effect over radar
      this.ctx.fillStyle = "rgba(168, 85, 247, 0.1)";
      for(let i=0; i<20; i++) {
        this.ctx.fillRect(Math.random() * 800, Math.random() * 500, Math.random() * 100, Math.random() * 10);
      }
    }
  }

  loop = () => {
    this.update();
    this.draw();
    this.animationFrameId = requestAnimationFrame(this.loop);
  }

  start() {
    this.loop();
  }

  stop() {
    cancelAnimationFrame(this.animationFrameId);
    this.canvas.removeEventListener('click', this.handleClick);
  }

  // --- GameManager Methods ---
  addFunds(amount: number) {
    this.funds += amount;
    this.notifyState();
  }

  triggerEMP() {
    this.jamTimer = 240;
    this.notifyState();
  }

  increaseThreat() {
    this.threatLevel += 1;
    this.notifyState();
  }

  repairCity() {
    this.integrity = 100;
    this.buildings.forEach(b => {
      b.hp = b.maxHp;
      b.height = b.maxHeight;
      b.fires = [];
    });
    this.notifyState();
  }
}

// --- React UI Component ---

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [showManager, setShowManager] = useState(false);
  
  const [gameState, setGameState] = useState<GameState>({
    funds: 600,
    integrity: 100,
    threatLevel: 1,
    isGameOver: false,
    launchDetected: false,
    isJammed: false
  });

  useEffect(() => {
    if (!canvasRef.current) return;
    const game = new Game(canvasRef.current, setGameState);
    gameRef.current = game;
    game.start();
    return () => game.stop();
  }, []);

  const handleRestart = () => {
    if (!canvasRef.current) return;
    if (gameRef.current) gameRef.current.stop();
    const game = new Game(canvasRef.current, setGameState);
    gameRef.current = game;
    game.start();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-mono flex flex-col items-center py-8 selection:bg-blue-500/30">
      
      <div className={`w-full max-w-4xl flex justify-between items-center bg-slate-900/80 backdrop-blur-md border p-4 rounded-2xl shadow-2xl mb-6 transition-colors duration-300 ${gameState.isJammed ? 'border-purple-500/50 shadow-purple-900/20' : gameState.launchDetected ? 'border-red-500/50 shadow-red-900/20' : 'border-blue-900/50 shadow-blue-900/20'}`}>
        <div>
          <h1 className="text-2xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400 uppercase flex items-center gap-2">
            <Radar className={`w-6 h-6 ${gameState.isJammed ? 'text-purple-500 animate-spin' : 'text-blue-500'}`} />
            Iron Dome Command
          </h1>
          <p className="text-xs text-slate-400 font-medium mt-1 uppercase tracking-widest">
            {gameState.isJammed ? <span className="text-purple-400 animate-pulse">JAMMER ACTIVE EMP</span> : "Air Defense Network Active"}
          </p>
        </div>
        
        <div className="flex gap-4">
          <div className="flex items-center gap-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
            <span className="text-slate-500 text-xs uppercase tracking-wider">Funds</span>
            <span className="text-xl font-bold text-green-400">${gameState.funds}</span>
          </div>
          <div className="flex items-center gap-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
            <span className="text-slate-500 text-xs uppercase tracking-wider">Integrity</span>
            <div className="flex items-center gap-2">
              <Activity className={`w-5 h-5 ${gameState.integrity <= 30 ? 'text-red-500 animate-pulse' : 'text-blue-400'}`} />
              <span className={`text-xl font-bold ${gameState.integrity <= 30 ? 'text-red-500' : 'text-blue-400'}`}>{gameState.integrity}%</span>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
            <span className="text-slate-500 text-xs uppercase tracking-wider">Threat</span>
            <AlertTriangle className="w-5 h-5 text-orange-400" />
            <span className="text-xl font-bold text-orange-400">Lv {gameState.threatLevel.toFixed(1)}</span>
          </div>
        </div>
      </div>

      <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-black ring-4 ring-slate-800">
        <canvas
          ref={canvasRef}
          width={800}
          height={500}
          className={`block bg-slate-950 ${gameState.isGameOver ? 'opacity-50 blur-sm' : ''} cursor-crosshair`}
        />
        
        {gameState.isGameOver && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md">
            <AlertTriangle className="w-20 h-20 text-red-500 mb-4 animate-pulse" />
            <h2 className="text-5xl font-black text-red-500 mb-2 tracking-widest">CITY DESTROYED</h2>
            <p className="text-lg text-slate-400 mb-8 font-mono">Defense network overwhelmed at Threat Level {gameState.threatLevel.toFixed(1)}</p>
            <button 
              onClick={handleRestart}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(37,99,235,0.4)] uppercase tracking-wider"
            >
              <RotateCcw className="w-5 h-5" />
              Reboot System
            </button>
          </div>
        )}
      </div>

      <div className="w-full max-w-4xl mt-6 bg-slate-900/50 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Crosshair className="w-5 h-5 text-blue-400" />
          <span className="text-sm text-slate-300">Click on the ground (bottom area) to deploy additional Iron Dome batteries.</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-sm font-bold text-green-400 bg-green-400/10 px-3 py-1 rounded-lg">
            Cost: $300 / Battery
          </div>
          <button 
            onClick={() => setShowManager(!showManager)}
            className={`p-2 rounded-lg transition-colors ${showManager ? 'bg-slate-700 text-white' : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'}`}
            title="Game Manager"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {showManager && (
        <div className="w-full max-w-4xl mt-4 bg-slate-900/80 backdrop-blur-md border border-slate-700 p-4 rounded-xl shadow-2xl animate-in slide-in-from-top-4 fade-in duration-200">
          <h3 className="text-lg font-bold text-slate-200 mb-4 flex items-center gap-2 uppercase tracking-wider">
            <Settings className="w-5 h-5 text-slate-400" />
            Game Manager
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <button 
              onClick={() => gameRef.current?.addFunds(1000)}
              className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-green-400 border border-slate-700 hover:border-green-500/50 px-4 py-3 rounded-lg font-bold text-sm transition-all"
            >
              <Plus className="w-4 h-4" /> Add $1000
            </button>
            <button 
              onClick={() => gameRef.current?.repairCity()}
              className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-blue-400 border border-slate-700 hover:border-blue-500/50 px-4 py-3 rounded-lg font-bold text-sm transition-all"
            >
              <Wrench className="w-4 h-4" /> Repair City
            </button>
            <button 
              onClick={() => gameRef.current?.triggerEMP()}
              className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-purple-400 border border-slate-700 hover:border-purple-500/50 px-4 py-3 rounded-lg font-bold text-sm transition-all"
            >
              <Zap className="w-4 h-4" /> Trigger EMP
            </button>
            <button 
              onClick={() => gameRef.current?.increaseThreat()}
              className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-orange-400 border border-slate-700 hover:border-orange-500/50 px-4 py-3 rounded-lg font-bold text-sm transition-all"
            >
              <ArrowUp className="w-4 h-4" /> Threat +1
            </button>
          </div>
        </div>
      )}
      
    </div>
  );
}
